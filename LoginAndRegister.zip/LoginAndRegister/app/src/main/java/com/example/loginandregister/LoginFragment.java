package com.example.loginandregister;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.login_fragment, container,false);

        Button btnLogar = (Button) v.findViewById(R.id.btnLogin);
        Button btnLimpar = (Button) v.findViewById(R.id.btnLimpar);

        btnLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }

        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LimparCampos();
            }
        });


        return v;

    }

    public void login(){
        EditText emailValue = (EditText) getView().findViewById(R.id.editTextTextEmailAddress);
        EditText passValue = (EditText) getView().findViewById(R.id.editTextTextPassword);
        TextView errorFeedback = (TextView) getView().findViewById(R.id.txtErrorAccount);

        String email = emailValue.getText().toString();
        String pass = emailValue.getText().toString();

        if (email.equals("") || passValue.equals("")){

            errorFeedback.setVisibility(View.VISIBLE);
            errorFeedback.setText("Todos os campos devem ser preenchidos");

            emailValue.setBackgroundResource(R.drawable.et_style);
            passValue.setBackgroundResource(R.drawable.et_style);

        }
    }

    public void LimparCampos(){

        EditText emailValue = (EditText) getView().findViewById(R.id.editTextTextEmailAddress);
        EditText passValue = (EditText) getView().findViewById(R.id.editTextTextPassword);

        emailValue.setText("");
        passValue.setText("");

    }
}
